import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { DirectiveDemoComponent } from './directive-demo-component/directive-demo-component';
import { StructuralDirectiveDemo } from './structural-directive-demo/structural-directive-demo';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet,DirectiveDemoComponent,StructuralDirectiveDemo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Directives_Demo');
}
