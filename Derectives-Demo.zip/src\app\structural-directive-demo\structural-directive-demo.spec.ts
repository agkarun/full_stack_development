import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StructuralDirectiveDemo } from './structural-directive-demo';

describe('StructuralDirectiveDemo', () => {
  let component: StructuralDirectiveDemo;
  let fixture: ComponentFixture<StructuralDirectiveDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StructuralDirectiveDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StructuralDirectiveDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
