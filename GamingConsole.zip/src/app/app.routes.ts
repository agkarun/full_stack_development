import { Routes } from '@angular/router';
import { LibraryComponent } from './components/library/library';
import { SnakeComponent } from './components/games/snake/snake';
import { Bricks } from './components/games/bricks/bricks';
import { Tanker } from './components/games/tanker/tanker';
import { Flappy } from './components/games/flappy/flappy';

export const routes: Routes = [
  { path: '', component: LibraryComponent },
  { path: 'play/snake', component: SnakeComponent },
  { path: 'play/bricks', component: Bricks },
  { path: 'play/tanker', component: Tanker },
  { path: 'play/flappy', component: Flappy },
  { path: '**', redirectTo: '' }
];