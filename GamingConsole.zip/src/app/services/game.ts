import { Injectable } from '@angular/core';

export interface Game {
  id: string;
  title: string;
  route: string;
  icon: string;
  color: string;
}

@Injectable({ providedIn: 'root' })
export class GameService {
  private games: Game[] = [
    { id: 'snake', title: 'Retro Snake', route: '/play/snake', icon: '🐍', color: '#4CAF50' },
    { id: 'bricks', title: 'Brick Breaker', route: '/play/bricks', icon: '🧱', color: '#FF5722' },
    { id: 'tanker', title: 'Tank Battalion', route: '/play/tanker', icon: '🚜', color: '#607d8b' },
    { id: 'flappy', title: 'Flappy Bird', route: '/play/flappy', icon: '🐦', color: '#FFEB3B' }
  ];

  getGames() { return this.games; }
}