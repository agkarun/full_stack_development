import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { GameService, Game } from '../../services/game';

@Component({
  selector: 'app-library',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="dashboard">
      <header>
        <h1>GAMING CONSOLE</h1>
        <p>Select a game to start playing</p>
      </header>
      
      <div class="game-grid">
        <div *ngFor="let game of games" 
             [routerLink]="game.route" 
             class="game-card" 
             [style.border-color]="game.color">
          <div class="game-icon">{{ game.icon }}</div>
          <h2>{{ game.title }}</h2>
          <span class="play-btn">PRESS START</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { background: #0a0a0a; color: white; min-height: 100vh; font-family: 'Segoe UI', sans-serif; padding: 40px; }
    header { text-align: center; margin-bottom: 50px; }
    h1 { font-size: 3rem; letter-spacing: 5px; color: #00d4ff; }
    .game-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; max-width: 1200px; margin: 0 auto; }
    .game-card { background: #1a1a1a; border: 2px solid; border-radius: 15px; padding: 30px; text-align: center; cursor: pointer; transition: 0.3s ease; }
    .game-card:hover { transform: translateY(-10px); background: #252525; box-shadow: 0 10px 20px rgba(0,0,0,0.5); }
    .game-icon { font-size: 4rem; margin-bottom: 15px; }
    .play-btn { display: inline-block; margin-top: 20px; font-weight: bold; color: #00d4ff; }
  `]
})
export class LibraryComponent {
  games: Game[];
  constructor(private gameService: GameService) {
    this.games = this.gameService.getGames();
  }
}