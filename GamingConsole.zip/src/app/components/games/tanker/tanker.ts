import { Component, ElementRef, HostListener, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Point { x: number; y: number; }
interface Bullet { x: number; y: number; dx: number; dy: number; }
interface Enemy { x: number; y: number; health: number; }

@Component({
  selector: 'app-tanker',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="game-container">
      <div class="hud">
        <button routerLink="/">MENU</button>
        <span class="score">ENEMIES DEFEATED: {{ score }}</span>
      </div>
      <canvas #gameCanvas width="500" height="500"></canvas>
    </div>
  `,
  styles: [`
    .game-container { background: #2c3e50; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; }
    .hud { width: 500px; display: flex; justify-content: space-between; margin-bottom: 10px; font-family: monospace; }
    canvas { background: #1a1a1a; border: 4px solid #95a5a6; }
    button { background: #e74c3c; border: none; color: white; padding: 5px 10px; cursor: pointer; }
    .score { color: #2ecc71; font-weight: bold; }
  `]
})
export class Tanker implements AfterViewInit, OnDestroy {
  @ViewChild('gameCanvas') canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;

  tank: Point = { x: 235, y: 450 };
  rotation = 0;
  bullets: Bullet[] = [];
  enemies: Enemy[] = [];
  score = 0;
  interval: any;
  spawnInterval: any;

  ngAfterViewInit() {
    this.ctx = this.canvas.nativeElement.getContext('2d')!;
    // Game Logic Loop (60 FPS)
    this.interval = setInterval(() => this.update(), 1000 / 60);
    // Enemy Spawner (Every 2 seconds)
    this.spawnInterval = setInterval(() => this.spawnEnemy(), 2000);
  }

  spawnEnemy() {
    if (this.enemies.length < 5) { // Limit enemies on screen
      this.enemies.push({
        x: Math.random() * 450,
        y: -30, // Start above the screen
        health: 1
      });
    }
  }

  @HostListener('window:keydown', ['$event'])
  handleInput(e: KeyboardEvent) {
    const step = 15;
    if (e.key === 'ArrowUp') { this.tank.y -= step; this.rotation = 0; }
    if (e.key === 'ArrowDown') { this.tank.y += step; this.rotation = 180; }
    if (e.key === 'ArrowLeft') { this.tank.x -= step; this.rotation = 270; }
    if (e.key === 'ArrowRight') { this.tank.x += step; this.rotation = 90; }
    if (e.code === 'Space') { this.fire(); }
  }

  fire() {
    let dx = 0, dy = 0;
    if (this.rotation === 0) dy = -7;
    if (this.rotation === 180) dy = 7;
    if (this.rotation === 90) dx = 7;
    if (this.rotation === 270) dx = -7;
    this.bullets.push({ x: this.tank.x + 15, y: this.tank.y + 15, dx, dy });
  }

  update() {
    // 1. Update Bullets
    this.bullets.forEach(b => { b.x += b.dx; b.y += b.dy; });
    this.bullets = this.bullets.filter(b => b.x > 0 && b.x < 500 && b.y > 0 && b.y < 500);

    // 2. Update Enemies (Move them down)
    this.enemies.forEach(enemy => {
      enemy.y += 1.5; // Slowly move toward player
    });

    // 3. Collision Detection (Bullets vs Enemies)
    this.bullets.forEach((bullet, bIndex) => {
      this.enemies.forEach((enemy, eIndex) => {
        if (bullet.x > enemy.x && bullet.x < enemy.x + 30 &&
            bullet.y > enemy.y && bullet.y < enemy.y + 30) {
          // Hit detected
          this.enemies.splice(eIndex, 1);
          this.bullets.splice(bIndex, 1);
          this.score++;
        }
      });
    });

    // 4. Game Over Check
    this.enemies.forEach(enemy => {
      if (enemy.y > 500) {
        alert("Enemy breached your base! Game Over.");
        this.resetGame();
      }
    });

    this.draw();
  }

  draw() {
    this.ctx.fillStyle = 'black';
    this.ctx.fillRect(0, 0, 500, 500);

    // Draw Player Tank
    this.drawTank(this.tank.x, this.tank.y, this.rotation, '#2ecc71');

    // Draw Enemies
    this.enemies.forEach(e => {
      this.drawTank(e.x, e.y, 180, '#e74c3c'); // Red tanks facing down
    });

    // Draw Bullets
    this.ctx.fillStyle = '#f1c40f';
    this.bullets.forEach(b => {
      this.ctx.beginPath();
      this.ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
      this.ctx.fill();
    });
  }

  drawTank(x: number, y: number, angle: number, color: string) {
    this.ctx.save();
    this.ctx.translate(x + 15, y + 15);
    this.ctx.rotate((angle * Math.PI) / 180);
    this.ctx.fillStyle = color;
    this.ctx.fillRect(-15, -15, 30, 30); // Body
    this.ctx.fillStyle = 'black';
    this.ctx.fillRect(-3, -20, 6, 15); // Barrel
    this.ctx.restore();
  }

  resetGame() {
    this.enemies = [];
    this.bullets = [];
    this.score = 0;
    this.tank = { x: 235, y: 450 };
  }

  ngOnDestroy() {
    clearInterval(this.interval);
    clearInterval(this.spawnInterval);
  }
}