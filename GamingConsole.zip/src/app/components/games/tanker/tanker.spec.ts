import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tanker } from './tanker';

describe('Tanker', () => {
  let component: Tanker;
  let fixture: ComponentFixture<Tanker>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Tanker]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Tanker);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
