import { Component, ElementRef, HostListener, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-flappy',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="game-container">
      <div class="hud">
        <button routerLink="/">EXIT</button>
        <span>Score: {{ score }} | High Score: {{ highScore }}</span>
      </div>
      <canvas #gameCanvas width="400" height="500"></canvas>
      <p>Press <strong>SPACE</strong> or <strong>CLICK</strong> to Jump</p>
    </div>
  `,
  styles: [`
    .game-container { background: #4ec0ca; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: 'Arial', sans-serif; }
    .hud { width: 400px; display: flex; justify-content: space-between; margin-bottom: 10px; font-weight: bold; color: white; text-shadow: 2px 2px #000; }
    canvas { background: #70c5ce; border: 4px solid #ded895; }
    button { background: #e67e22; border: none; color: white; padding: 5px 15px; cursor: pointer; border-radius: 5px; }
  `]
})
export class Flappy implements AfterViewInit, OnDestroy {
  @ViewChild('gameCanvas') canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;

  // Bird
  birdY = 250;
  velocity = 0;
  gravity = 0.25;
  jump = -4.6;

  // Pipes
  pipes: any[] = [];
  pipeWidth = 50;
  pipeGap = 150;
  
  score = 0;
  highScore = 0;
  gameLoop: any;

  ngAfterViewInit() {
    this.ctx = this.canvas.nativeElement.getContext('2d')!;
    this.resetGame();
    this.gameLoop = setInterval(() => this.update(), 1000 / 60);
  }

  @HostListener('window:keydown', ['$event'])
  handleInput(e: KeyboardEvent) {
    if (e.code === 'Space') this.flap();
  }

  @HostListener('window:mousedown')
  handleMouse() { this.flap(); }

  flap() { this.velocity = this.jump; }

  resetGame() {
    this.birdY = 250;
    this.velocity = 0;
    this.pipes = [{ x: 400, y: 150 }];
    this.score = 0;
  }

  update() {
    // Bird Physics
    this.velocity += this.gravity;
    this.birdY += this.velocity;

    // Floor/Ceiling collision
    if (this.birdY > 500 || this.birdY < 0) this.resetGame();

    // Pipe Logic
    this.pipes.forEach(pipe => {
      pipe.x -= 2; // Move left

      // Collision Check
      if (pipe.x < 50 + 20 && pipe.x + this.pipeWidth > 50) {
        if (this.birdY < pipe.y || this.birdY > pipe.y + this.pipeGap) {
          this.resetGame();
        }
      }

      // Scoring
      if (pipe.x === 50) {
        this.score++;
        if (this.score > this.highScore) this.highScore = this.score;
      }
    });

    // Add new pipes
    if (this.pipes[this.pipes.length - 1].x < 200) {
      this.pipes.push({
        x: 400,
        y: Math.random() * 250 + 50
      });
    }

    // Remove old pipes
    if (this.pipes[0].x < -50) this.pipes.shift();

    this.draw();
  }

  draw() {
    // Background
    this.ctx.fillStyle = "#70c5ce";
    this.ctx.fillRect(0, 0, 400, 500);

    // Pipes
    this.ctx.fillStyle = "#2ecc71";
    this.pipes.forEach(pipe => {
      this.ctx.fillRect(pipe.x, 0, this.pipeWidth, pipe.y); // Top
      this.ctx.fillRect(pipe.x, pipe.y + this.pipeGap, this.pipeWidth, 500); // Bottom
    });

    // Bird
    this.ctx.fillStyle = "#f1c40f";
    this.ctx.beginPath();
    this.ctx.arc(60, this.birdY, 15, 0, Math.PI * 2);
    this.ctx.fill();
  }

  ngOnDestroy() { clearInterval(this.gameLoop); }
}