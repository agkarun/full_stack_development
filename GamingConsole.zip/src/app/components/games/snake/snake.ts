import { Component, ElementRef, HostListener, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-snake',
  standalone: true,
  imports: [RouterModule],
  template: `
    <div class="game-container">
      <div class="hud">
        <button routerLink="/">BACK TO MENU</button>
        <span class="score">SCORE: {{ score }}</span>
      </div>
      <canvas #gameCanvas width="400" height="400"></canvas>
    </div>
  `,
  styles: [`
    .game-container { background: #111; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .hud { margin-bottom: 20px; width: 400px; display: flex; justify-content: space-between; color: white; }
    canvas { border: 5px solid #333; box-shadow: 0 0 20px rgba(0,255,0,0.2); background: #000; }
    button { padding: 8px 15px; cursor: pointer; background: #444; color: white; border: none; }
  `]
})
export class SnakeComponent implements AfterViewInit, OnDestroy {
  @ViewChild('gameCanvas') canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;
  snake = [{x: 10, y: 10}];
  food = {x: 5, y: 5};
  dir = {x: 0, y: 0};
  score = 0;
  gameLoop: any;

  ngAfterViewInit() {
    this.ctx = this.canvas.nativeElement.getContext('2d')!;
    this.gameLoop = setInterval(() => this.update(), 120);
  }

  @HostListener('window:keydown', ['$event'])
  onKey(e: KeyboardEvent) {
    if (e.key === 'ArrowUp' && this.dir.y !== 1) this.dir = {x: 0, y: -1};
    if (e.key === 'ArrowDown' && this.dir.y !== -1) this.dir = {x: 0, y: 1};
    if (e.key === 'ArrowLeft' && this.dir.x !== 1) this.dir = {x: -1, y: 0};
    if (e.key === 'ArrowRight' && this.dir.x !== -1) this.dir = {x: 1, y: 0};
  }

  update() {
    if (this.dir.x === 0 && this.dir.y === 0) return;
    const head = {x: this.snake[0].x + this.dir.x, y: this.snake[0].y + this.dir.y};
    
    // Check collision
    if (head.x < 0 || head.x >= 20 || head.y < 0 || head.y >= 20) {
      alert('Game Over! Score: ' + this.score);
      this.reset();
      return;
    }

    this.snake.unshift(head);
    if (head.x === this.food.x && head.y === this.food.y) {
      this.score += 10;
      this.food = {x: Math.floor(Math.random()*20), y: Math.floor(Math.random()*20)};
    } else {
      this.snake.pop();
    }
    this.draw();
  }

  draw() {
    this.ctx.fillStyle = 'black';
    this.ctx.fillRect(0, 0, 400, 400);
    this.ctx.fillStyle = '#4CAF50';
    this.snake.forEach(s => this.ctx.fillRect(s.x*20, s.y*20, 19, 19));
    this.ctx.fillStyle = 'red';
    this.ctx.fillRect(this.food.x*20, this.food.y*20, 19, 19);
  }

  reset() {
    this.snake = [{x: 10, y: 10}];
    this.dir = {x: 0, y: 0};
    this.score = 0;
  }

  ngOnDestroy() { clearInterval(this.gameLoop); }
}