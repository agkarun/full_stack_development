import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bricks } from './bricks';

describe('Bricks', () => {
  let component: Bricks;
  let fixture: ComponentFixture<Bricks>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Bricks]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Bricks);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
