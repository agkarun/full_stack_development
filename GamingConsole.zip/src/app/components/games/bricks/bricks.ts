import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, HostListener } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-bricks',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="game-wrap">
      <div class="hud">
        <button routerLink="/">EXIT TO MENU</button>
        <div class="stats">
          <span>SCORE: {{ score }}</span> | <span>LIVES: {{ lives }}</span>
        </div>
      </div>
      <canvas #brickCanvas width="480" height="320"></canvas>
    </div>
  `,
  styles: [`
    .game-wrap { background: #1a1a1a; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #fff; font-family: 'Courier New', monospace; }
    .hud { width: 480px; display: flex; justify-content: space-between; margin-bottom: 15px; }
    canvas { background: #000; border: 4px solid #444; box-shadow: 0 0 20px rgba(255, 87, 34, 0.3); cursor: none; }
    button { padding: 5px 15px; cursor: pointer; background: #ff5722; color: white; border: none; font-weight: bold; }
    .stats { font-size: 1.2rem; color: #ffeb3b; }
  `]
})
export class Bricks implements AfterViewInit, OnDestroy {
  @ViewChild('brickCanvas') canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;

  // Game Settings
  ballRadius = 8;
  paddleHeight = 10;
  paddleWidth = 75;
  brickRowCount = 3;
  brickColumnCount = 5;
  brickWidth = 75;
  brickHeight = 20;
  brickPadding = 10;
  brickOffsetTop = 30;
  brickOffsetLeft = 30;

  // Game State
  x = 0; y = 0; dx = 2; dy = -2;
  paddleX = 0;
  score = 0;
  lives = 3;
  bricks: any[] = [];
  interval: any;

  ngAfterViewInit() {
    this.ctx = this.canvas.nativeElement.getContext('2d')!;
    this.resetBall();
    this.initBricks();
    this.interval = setInterval(() => this.draw(), 10);
  }

  initBricks() {
    for (let c = 0; c < this.brickColumnCount; c++) {
      this.bricks[c] = [];
      for (let r = 0; r < this.brickRowCount; r++) {
        this.bricks[c][r] = { x: 0, y: 0, status: 1 };
      }
    }
  }

  @HostListener('window:mousemove', ['$event'])
  movePaddle(e: MouseEvent) {
    const rect = this.canvas.nativeElement.getBoundingClientRect();
    const relativeX = e.clientX - rect.left;
    if (relativeX > 0 && relativeX < this.canvas.nativeElement.width) {
      this.paddleX = relativeX - this.paddleWidth / 2;
    }
  }

  collisionDetection() {
    for (let c = 0; c < this.brickColumnCount; c++) {
      for (let r = 0; r < this.brickRowCount; r++) {
        const b = this.bricks[c][r];
        if (b.status === 1) {
          if (this.x > b.x && this.x < b.x + this.brickWidth && this.y > b.y && this.y < b.y + this.brickHeight) {
            this.dy = -this.dy;
            b.status = 0;
            this.score++;
            if (this.score === this.brickRowCount * this.brickColumnCount) {
              alert("CONGRATULATIONS! YOU WON!");
              this.resetGame();
            }
          }
        }
      }
    }
  }

  draw() {
    this.ctx.clearRect(0, 0, 480, 320);
    this.drawBricks();
    this.drawBall();
    this.drawPaddle();
    this.collisionDetection();

    // Wall Collision (Left/Right)
    if (this.x + this.dx > 480 - this.ballRadius || this.x + this.dx < this.ballRadius) {
      this.dx = -this.dx;
    }
    // Wall Collision (Top)
    if (this.y + this.dy < this.ballRadius) {
      this.dy = -this.dy;
    } 
    // Paddle/Bottom Collision
    else if (this.y + this.dy > 320 - this.ballRadius) {
      if (this.x > this.paddleX && this.x < this.paddleX + this.paddleWidth) {
        this.dy = -this.dy;
      } else {
        this.lives--;
        if (!this.lives) {
          alert("GAME OVER");
          this.resetGame();
        } else {
          this.resetBall();
        }
      }
    }

    this.x += this.dx;
    this.y += this.dy;
  }

  drawBall() {
    this.ctx.beginPath();
    this.ctx.arc(this.x, this.y, this.ballRadius, 0, Math.PI * 2);
    this.ctx.fillStyle = "#ffeb3b";
    this.ctx.fill();
    this.ctx.closePath();
  }

  drawPaddle() {
    this.ctx.beginPath();
    this.ctx.rect(this.paddleX, 320 - this.paddleHeight, this.paddleWidth, this.paddleHeight);
    this.ctx.fillStyle = "#ff5722";
    this.ctx.fill();
    this.ctx.closePath();
  }

  drawBricks() {
    for (let c = 0; c < this.brickColumnCount; c++) {
      for (let r = 0; r < this.brickRowCount; r++) {
        if (this.bricks[c][r].status === 1) {
          const brickX = c * (this.brickWidth + this.brickPadding) + this.brickOffsetLeft;
          const brickY = r * (this.brickHeight + this.brickPadding) + this.brickOffsetTop;
          this.bricks[c][r].x = brickX;
          this.bricks[c][r].y = brickY;
          this.ctx.beginPath();
          this.ctx.rect(brickX, brickY, this.brickWidth, this.brickHeight);
          this.ctx.fillStyle = "#03a9f4";
          this.ctx.fill();
          this.ctx.closePath();
        }
      }
    }
  }

  resetBall() {
    this.x = 240;
    this.y = 290;
    this.dx = 2;
    this.dy = -2;
    this.paddleX = (480 - this.paddleWidth) / 2;
  }

  resetGame() {
    this.score = 0;
    this.lives = 3;
    this.initBricks();
    this.resetBall();
  }

  ngOnDestroy() {
    if (this.interval) clearInterval(this.interval);
  }
}