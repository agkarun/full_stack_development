import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RoomAC } from './room-ac/room-ac';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RoomAC,CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('AC-Project');
}
