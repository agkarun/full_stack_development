import { Component } from '@angular/core';
import { ACService } from '../ac-service';

@Component({
  selector: 'app-room-ac',
  imports: [],
  templateUrl: './room-ac.html',
  styleUrl: './room-ac.css',
})
export class RoomAC {
  acStatus:string="";
  constructor(private service: ACService){}
  onAC(){
    this.acStatus=this.service.onAC();
  }

  offAC(){
    this.acStatus=this.service.offAC();
  }
}
