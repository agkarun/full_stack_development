import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ACService {
  onAC(){
    return "AC is ON";
  }

  offAC(){
    return "AC is OFF";
  }
}
