import { TestBed } from '@angular/core/testing';

import { ACService } from './ac-service';

describe('ACService', () => {
  let service: ACService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ACService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
