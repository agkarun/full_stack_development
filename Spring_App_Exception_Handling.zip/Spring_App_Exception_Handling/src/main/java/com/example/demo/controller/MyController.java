package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception_demo.Employee;
import com.example.demo.services.MyService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;




@RestController
public class MyController {
	@Autowired
	private MyService service;
	
	@GetMapping("/getAllEmployee")
	public List<Employee> getAllEmployee() {
		return service.getAllEmployee();
	}
	
	@GetMapping("/getAllEmployee/{id}")
	public Employee getAllEmployeeByID(@PathVariable int id) {
		return service.getEmployeeById(id);
	}
	
	@PostMapping("/addEmployee")
	public String addEmployee(@RequestBody Employee employee) {
		return service.addEmployee(employee);
	}
	
	@PutMapping("updateEmployee/{id}")
	public String updateEmployee(@PathVariable int id, @RequestBody Employee updateEmployee) {
		return service.updateEmployee(id, updateEmployee);
	}
	
	@DeleteMapping("/deleteAllEmployee")
	public String deleteAllEmployee() {
		return service.deleteAllEmployees();
	}
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable int id) {
		return service.deleteEmployee(id);
	}
}
