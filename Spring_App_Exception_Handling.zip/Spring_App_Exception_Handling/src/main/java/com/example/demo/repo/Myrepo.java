package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.exception_demo.Employee;

public interface Myrepo extends JpaRepository<Employee, Integer> {

}
