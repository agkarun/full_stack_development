package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAppExceptionHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAppExceptionHandlingApplication.class, args);
		System.out.println("Springboot Exception Handling App.....");
	}

}
