import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-calc',
  imports: [FormsModule],
  templateUrl: './calc.html',
  styleUrl: './calc.css',
})
export class Calc {
  number_1:number=0;
  number_2:number=0;

  add(){
    alert(this.number_1+this.number_2)
  }
  subtract(){
    alert(this.number_1-this.number_2)
  }
}
