import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Calc } from './calc/calc';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Calc],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('CalculatorApp');
}
