package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAppMySqlDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAppMySqlDbApplication.class, args);
	}

}
