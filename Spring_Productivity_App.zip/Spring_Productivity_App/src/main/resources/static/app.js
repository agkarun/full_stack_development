const BASE_URL = "http://localhost:8080/api";
let currentUser = null;

// 1. AUTHENTICATION (Login & Register)
async function auth(type) {
    const user = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value
    };

    if (!user.username || !user.password) return alert("Fields cannot be empty");

    try {
        const response = await fetch(`${BASE_URL}/users/${type}`, {
            method: 'POST', // Prevents 405 error
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user)
        });

        if (response.ok) {
            const data = await response.json();
            if (type === 'login') {
                currentUser = data;
                showDashboard();
            } else {
                alert("Registration successful! Now please login.");
            }
        } else {
            const msg = await response.text();
            alert("Error: " + (msg || "Invalid credentials"));
        }
    } catch (err) {
        console.error("Connection failed", err);
    }
}

function showDashboard() {
    document.getElementById('auth-section').style.display = 'none';
    document.getElementById('app-section').style.display = 'block';
    document.getElementById('display-user').innerText = currentUser.username;
    loadTasks();
}

// 2. TASK MANAGEMENT
async function loadTasks() {
    // Note: You'll need a @GetMapping("/api/tasks/user/{id}") in Spring Boot
    const res = await fetch(`${BASE_URL}/tasks/user/${currentUser.id}`);
    const tasks = await res.json();
    renderTasks(tasks);
    updateAnalytics(tasks);
}

async function addTask() {
    const title = document.getElementById('taskTitle').value;
    if (!title) return;

    const taskObj = {
        title: title,
        completed: false,
        user: { id: currentUser.id } // Linking task to the unique user
    };

    await fetch(`${BASE_URL}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskObj)
    });

    document.getElementById('taskTitle').value = '';
    loadTasks();
}

async function toggleTask(taskId, isComplete) {
    await fetch(`${BASE_URL}/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: !isComplete })
    });
    loadTasks();
}

// 3. UI RENDERING & ANALYTICS
function renderTasks(tasks) {
    const list = document.getElementById('taskList');
    list.innerHTML = tasks.map(t => `
        <li class="${t.completed ? 'completed' : ''}">
            <input type="checkbox" ${t.completed ? 'checked' : ''} 
                   onclick="toggleTask(${t.id}, ${t.completed})">
            ${t.title}
        </li>
    `).join('');
}

function updateAnalytics(tasks) {
    const total = tasks.length;
    const done = tasks.filter(t => t.completed).length;
    const percent = total === 0 ? 0 : Math.round((done / total) * 100);

    document.getElementById('stat-total').innerText = total;
    document.getElementById('stat-done').innerText = done;
    document.getElementById('progress-fill').style.width = percent + "%";
}

function logout() {
    location.reload(); // Simple way to clear state
}