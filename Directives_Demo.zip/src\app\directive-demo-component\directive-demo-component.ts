import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-demo-component',
  imports: [],
  templateUrl: './directive-demo-component.html',
  styleUrl: './directive-demo-component.css',
})
export class DirectiveDemoComponent {
  name:string="My Name"
  course:string="Course Name"
  fee:number=999;

}
