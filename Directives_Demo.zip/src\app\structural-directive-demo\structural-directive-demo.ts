import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structural-directive-demo',
  imports: [CommonModule],
  templateUrl: './structural-directive-demo.html',
  styleUrl: './structural-directive-demo.css',
})
export class StructuralDirectiveDemo {
  isLoggedIn:boolean=false;
//  ngif
  login(){
    this.isLoggedIn=true;
  }

  logout(){
    this.isLoggedIn=false;
  }
  // ngfor
  courses:string[] = ["Angular","Javascript","HTML", "Java"]

  // ngSwitch
  role:string="";
  setRole(newRole:string){
    this.role=newRole;
  }
}
