package com.example.photoapp;

import org.springframework.stereotype.Service;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;

@Service
public class PhotoService {

	public String processImages(List<BufferedImage> images, String theme) throws IOException {
	    int canvasSize = 900;
	    BufferedImage canvas = new BufferedImage(canvasSize, canvasSize, BufferedImage.TYPE_INT_ARGB);
	    Graphics2D g = canvas.createGraphics();
	    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

	    // Set Background based on theme
	    if (theme.equals("polaroid")) {
	        g.setColor(new Color(240, 240, 240)); // Off-white
	    } else {
	        g.setPaint(new GradientPaint(0, 0, new Color(20, 30, 48), 0, canvasSize, new Color(36, 59, 85)));
	    }
	    g.fillRect(0, 0, canvasSize, canvasSize);

	    int margin = 50;
	    int imgSize = 350;

	    for (int i = 0; i < Math.min(images.size(), 4); i++) {
	        int x = margin + (i % 2) * (imgSize + margin);
	        int y = margin + (i / 2) * (imgSize + margin);

	        switch (theme) {
	            case "polaroid" -> drawPolaroid(g, images.get(i), x, y, imgSize);
	            case "glass" -> drawGlassFrame(g, images.get(i), x, y, imgSize);
	            default -> { // Modern Default
	                g.drawImage(images.get(i), x, y, imgSize, imgSize, null);
	                g.setColor(Color.WHITE);
	                g.setStroke(new BasicStroke(5));
	                g.drawRect(x, y, imgSize, imgSize);
	            }
	        }
	    }
	    
	    g.dispose();
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    ImageIO.write(canvas, "png", baos);
	    return Base64.getEncoder().encodeToString(baos.toByteArray());
	}
	
	private void drawGlassFrame(Graphics2D g, BufferedImage img, int x, int y, int size) {
	    // Soft outer glow
	    g.setColor(new Color(255, 255, 255, 30));
	    g.fillRoundRect(x - 5, y - 5, size + 10, size + 10, 25, 25);

	    // Rounded Image
	    Shape oldClip = g.getClip();
	    g.setClip(new java.awt.geom.RoundRectangle2D.Float(x, y, size, size, 20, 20));
	    g.drawImage(img, x, y, size, size, null);
	    g.setClip(oldClip);

	    // Frosty border
	    g.setStroke(new BasicStroke(2));
	    g.setColor(new Color(255, 255, 255, 150));
	    g.drawRoundRect(x, y, size, size, 20, 20);
	}
	
	private void drawPolaroid(Graphics2D g, BufferedImage img, int x, int y, int size) {
	    int padding = 10;
	    int bottomSpace = 40;

	    // Draw the white paper backing
	    g.setColor(Color.WHITE);
	    g.fillRect(x, y, size, size + bottomSpace);

	    // Draw the photo inside
	    g.drawImage(img, x + padding, y + padding, size - (padding * 2), size - (padding * 2), null);

	    // Add a slight "shadow" border
	    g.setColor(new Color(0, 0, 0, 30));
	    g.drawRect(x, y, size, size + bottomSpace);
	}
}