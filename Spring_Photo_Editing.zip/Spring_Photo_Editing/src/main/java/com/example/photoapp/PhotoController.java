package com.example.photoapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

@Controller
public class PhotoController {

    @Autowired
    private PhotoService photoService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/create-collage")
    public String createCollage(@RequestParam("files") MultipartFile[] files, 
                                @RequestParam(value = "theme", defaultValue = "modern") String theme,
                                Model model) throws Exception {
        
        List<BufferedImage> images = new ArrayList<>();
        for (MultipartFile file : files) {
            // Read the image and add to list
            BufferedImage bi = ImageIO.read(file.getInputStream());
            if (bi != null) {
                images.add(bi);
            }
        }
        
        // Pass the 'theme' String here, matching the Service method signature
        String base64Image = photoService.processImages(images, theme);
        
        model.addAttribute("resultImage", "data:image/png;base64," + base64Image);
        return "index";
    }
}
