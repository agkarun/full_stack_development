package com.example.photoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPhotoEditingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPhotoEditingApplication.class, args);
	}

}
