import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-pipe-demo',
  imports: [CommonModule],
  templateUrl: './pipe-demo.html',
  styleUrl: './pipe-demo.css',
})
export class PipeDemo {

  name:string="Sample Name"
  amount:number=50000
  today:Date=new Date();
  emp={
    id:'1',
    name:'This Name',
    role:'This Role',
    salary:'120000'
  }
}
