import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';
import { PipeDemo } from './pipe-demo/pipe-demo';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CommonModule,FormsModule,PipeDemo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Template_Driven_Example');

  formData: any = {};

  submitData(form: any) {
  this.formData = form.value;
}

}
