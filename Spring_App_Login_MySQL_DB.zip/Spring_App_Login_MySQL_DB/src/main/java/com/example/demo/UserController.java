package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	@Autowired
    private UserRepository repo;
	
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/register")
	public String addUser(@RequestParam String username, @RequestParam String password) {
		ResponseEntity<User> entity = new ResponseEntity<>(repo.save(new User(username,password)), HttpStatus.CREATED);
		
		if (entity.getStatusCode()==HttpStatus.CREATED) {
			return "login";
		}
		return "register";
    }
	
	@PostMapping("/login")
	public String userLogin(@RequestParam String username, @RequestParam String password) {
		if(repo.findByUserNameAndPassword(username, password).isPresent()) {
			return "welcome";
		}
		return "/register";
        
    }
}
