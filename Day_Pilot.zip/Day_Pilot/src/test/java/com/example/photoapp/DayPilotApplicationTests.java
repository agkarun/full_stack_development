package com.example.photoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DayPilotApplicationTests {

	@Test
	void contextLoads() {
	}

}
