const API="http://localhost:8080";

function register(){

fetch(API+"/auth/register",{
 method:"POST",
 headers:{'Content-Type':'application/json'},
 body:JSON.stringify({
  username:ruser.value,
  password:rpass.value
 })
});
}

function login(){

fetch(API+"/auth/login",{
 method:"POST",
 headers:{'Content-Type':'application/json'},
 body:JSON.stringify({
  username:username.value,
  password:password.value
 })
})
.then(r=>r.json())
.then(u=>{
 localStorage.setItem("user",u.username);
 location="dashboard.html";
});
}

function addTask(){

fetch(`${API}/tasks/${localStorage.getItem("user")}`,{
 method:"POST",
 headers:{'Content-Type':'application/json'},
 body:JSON.stringify({
  title:task.value
 })
}).then(loadTasks);
}

function complete(id){
fetch(`${API}/tasks/complete/${id}`,
{method:"PUT"}).then(loadTasks);
}

function loadTasks(){

fetch(`${API}/tasks/${localStorage.getItem("user")}`)
.then(r=>r.json())
.then(data=>{

let html="";

data.forEach(t=>{
html+=`
<li>
${t.title}
${t.completed?"✅":
`<button onclick="complete(${t.id})">Done</button>`}
</li>`;
});

tasks.innerHTML=html;
loadAnalytics();
});
}

function loadAnalytics(){

fetch(`${API}/tasks/analytics/${localStorage.getItem("user")}`)
.then(r=>r.json())
.then(a=>{
analytics.innerHTML=
`Completed ${a.completed}/${a.total}`;
});
}

loadTasks();