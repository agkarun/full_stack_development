package com.example.daypilotapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.daypilotapp.model.Task;
import com.example.daypilotapp.model.User;

import java.util.List;

public interface TaskRepository
 extends JpaRepository<Task,Long>{

 List<Task> findByUser(User user);
}