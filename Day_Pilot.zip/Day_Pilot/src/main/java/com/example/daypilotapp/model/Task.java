package com.example.daypilotapp.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Task {

 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;

 private String title;

 private boolean completed=false;

 private LocalDateTime createdAt;
 private LocalDateTime completedAt;

 @ManyToOne
 @JoinColumn(name="user_id")
 private User user;

 public Task(){}

 @PrePersist
 public void created(){
  createdAt=LocalDateTime.now();
 }

 /* GETTERS & SETTERS */

 public Long getId(){ return id; }
 public void setId(Long id){ this.id=id; }

 public String getTitle(){ return title; }
 public void setTitle(String title){ this.title=title; }

 public boolean isCompleted(){ return completed; }

 public void setCompleted(boolean completed){
  this.completed=completed;

  if(completed)
   completedAt=LocalDateTime.now();
  else
   completedAt=null;
 }

 public User getUser(){ return user; }
 public void setUser(User user){ this.user=user; }
}