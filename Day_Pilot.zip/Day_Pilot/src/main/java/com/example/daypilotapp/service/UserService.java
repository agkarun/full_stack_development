package com.example.daypilotapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.daypilotapp.model.User;
import com.example.daypilotapp.repository.UserRepository;


@Service
public class UserService {

 @Autowired
 UserRepository repo;

 public User register(User user){
  return repo.save(user);
 }

 public User login(String username,String password){

  User user=repo.findByUsername(username)
        .orElseThrow();

  if(!user.getPassword().equals(password))
      throw new RuntimeException("Invalid login");

  return user;
 }
}