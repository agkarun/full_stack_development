package com.example.daypilotapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.daypilotapp.model.Task;
import com.example.daypilotapp.service.TaskService;

import java.util.List;

@RestController
@RequestMapping("/tasks")
@CrossOrigin
public class TaskController {

 @Autowired
 TaskService service;

 @PostMapping("/{username}")
 public Task add(
   @PathVariable String username,
   @RequestBody Task task){

  return service.addTask(username,task);
 }

 @GetMapping("/{username}")
 public List<Task> get(
   @PathVariable String username){

  return service.getTasks(username);
 }

 @PutMapping("/complete/{id}")
 public Task complete(@PathVariable Long id){
  return service.complete(id);
 }
}