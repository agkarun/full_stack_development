package com.example.daypilotapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.daypilotapp.dto.LoginRequest;
import com.example.daypilotapp.model.User;
import com.example.daypilotapp.service.UserService;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

 @Autowired
 UserService service;

 @PostMapping("/register")
 public User register(@RequestBody User user){
  return service.register(user);
 }

 @PostMapping("/login")
 public User login(
      @RequestBody LoginRequest req){

  return service.login(
      req.getUsername(),
      req.getPassword());
 }
}