package com.example.daypilotapp.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.daypilotapp.model.Task;
import com.example.daypilotapp.model.User;
import com.example.daypilotapp.repository.TaskRepository;
import com.example.daypilotapp.repository.UserRepository;

import java.util.*;

@Service
public class TaskService {

 @Autowired
 TaskRepository repo;

 @Autowired
 UserRepository userRepo;

 public Task addTask(String username,Task task){

  User user=userRepo
      .findByUsername(username)
      .orElseThrow();

  task.setUser(user);

  return repo.save(task);
 }

 public List<Task> getTasks(String username){

  User user=userRepo
      .findByUsername(username)
      .orElseThrow();

  return repo.findByUser(user);
 }

 public Task complete(Long id){

  Task task=repo.findById(id).orElseThrow();

  task.setCompleted(true);

  return repo.save(task);
 }
}