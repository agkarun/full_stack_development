package java_basics;

abstract class Operations1 {
	abstract void withdraw();

	abstract void deposite();

}

public class ATM1 extends Operations1{

	void withdraw() {
		System.out.println("hello atm");
	}

	void deposite() {
		System.out.println("hello indian bank");
	}

	public static void main(String[] args) {
		ATM1 xy = new ATM1();
		xy.withdraw();
		xy.deposite();
	}
}