package java_basics;

public class ExceptionHandling {

	public static void main(String[] args) {
		int i[]= {1,2};
		try {
			System.out.println("Start of try block");
			int j=1/0;
			System.out.println(i[2]);
			System.out.println("End of try block");
			
			
			try {
				System.out.println("Start of try block");
				int k=1/0;
				System.out.println(i[2]);
				System.out.println("End of try block");
			}
			catch(ArithmeticException e) {
				System.out.println(e);
			}
			
			
		}
		catch(ArithmeticException e) {
			
			
			try {
				System.out.println("Start of try block");
				int k=1/0;
				System.out.println(i[2]);
				System.out.println("End of try block");
			}
			catch(ArithmeticException e1) {
				System.out.println(e);
			}
				
			
			System.out.println(e);
		}
		
		
		catch(IndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch(Exception e) {
			System.out.println("In parent");
		}

		System.out.println("End of main method");
	}

}
