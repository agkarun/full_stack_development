package java_basics;

public class Basic_Math {

	public static void main(String[] args) {
		Basic_Math math = new Basic_Math();
		math.add(5, 5);
		math.subtract(5, 5);
		math.multiply(5, 5);
		math.divide(5, 5);	
	}

	public void add(int a, int b) {
		System.out.println("Addition:"+(5+5));
	}
	
	public void subtract(int a, int b) {
		System.out.println("Subtraction:"+(5-5));
	}
	
	public void multiply(int a, int b) {
		System.out.println("Multiplication:"+(5*5));
	}
	
	public void divide(int a, int b) {
		System.out.println("Division:"+(5/5));
	}
}
