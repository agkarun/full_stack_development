package java_basics;

public class Encapsulation2 {
	int a ;
	void m1(int a)
	{
		System.out.println("dgf"+a);
		this.a=a;
	}
	void m2()
	{
		System.out.println("tha vlue of thee c is"+a);
	}
public static void main(String[] args) {
	Encapsulation2  ss = new Encapsulation2();
	ss.m1(3);
	ss.m2();
}
}
