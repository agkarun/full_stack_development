package java_basics;

class Abcs
{
private	int a;
	
public int getA() {
	return a;
}

public void setA(int a) {
	this.a = a;
}

	
}
public class Inheritance1 extends Abcs {

public static void main(String[] args) {
	Inheritance1  xy = new Inheritance1();
    xy.setA(22);
    System.out.println(xy.getA());
	
}
}