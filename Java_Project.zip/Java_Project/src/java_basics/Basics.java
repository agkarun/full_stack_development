package java_basics;

public class Basics {
	int i=1;
	
	public Basics() {
		System.out.println("Object 1 Created.....");
	}
	
	public Basics(String message) {
		System.out.println("Object 2 "+ message);
	}
	
	static {
		System.out.println("Static Block");
	}
	
	{
		System.out.println("Instance Block");
	}
	
	public void method(String message) {
		System.out.println(message);
	}

	public static void main(String[] args) {
		System.out.println("Starting Main method....");
		Basics basics1 = new Basics();
		Basics basics2 = new Basics("Created.....");
		basics1.method("Calling from basics1");
		basics2.method("Calling from basics2");

	}

}
