package java_basics;

class GrandFather 
{
	void sugar()
	{
		System.out.println("i am having sugar");
	}
}

class father extends GrandFather{
	void bp()
	{

		System.out.println("I am having BP");
	}
}

public class Child extends father {
	
public static void main(String[] args) {
	Child  cc = new Child();
	cc.bp();
	cc.sugar();
}
}
