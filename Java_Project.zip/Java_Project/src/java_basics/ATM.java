package java_basics;

abstract class Operations {
	abstract void withdraw();

	abstract void deposite();
}

abstract class Abc extends Operations {

	@Override
	void withdraw() {
		System.out.println("asdfasdf");
	}

}

public class ATM extends Abc {
	@Override
	void deposite() {
		System.out.println("ahello wrld");
	}

	public static void main(String[] args) {
		ATM xy = new ATM();
		xy.withdraw();
		xy.deposite();
	}

}

