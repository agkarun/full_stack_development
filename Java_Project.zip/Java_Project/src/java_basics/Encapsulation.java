package java_basics;

public class Encapsulation {
	int b=8;
	   void m2(int b) 
	   {
		   System.out.println("hello "+b);
		   System.out.println("hello "+this.b);
	   }
public static void main(String[] args) {
	Encapsulation  xy = new Encapsulation();
	xy.m2(3);
}
}
