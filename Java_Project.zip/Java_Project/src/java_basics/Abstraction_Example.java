package java_basics;

abstract class Abcd
{
	abstract  void m1() ;
}

public class Abstraction_Example extends Abcd {
	void m1()
	{	
		System.out.println("method m1");
	}

	public static void main(String[] args) {
		Abstraction_Example  xy = new Abstraction_Example();
		xy.m1();
	}
}
