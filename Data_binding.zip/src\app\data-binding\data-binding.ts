import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding {
  // Interpolation
  name = "This is name from interpolation"
  // Property Bing
  isDisabled=false;
  submitStatus="Disable Submit"
  // Event Binding
  disableSubmit(){
    if(this.isDisabled) {
      this.isDisabled=false;
      this.submitStatus="Disable Submit"
    }
    else{
      this.isDisabled=true;
      this.submitStatus="Enable Submit"

      
    } 
  }
  // two way binding
  username=""
  showAlert(){
    alert("Hello "+this.username);
  }

}
