package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class EmployeeLoginController {
	 // Show Login Page
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // Process Login
    @PostMapping("/login")
    public String validateLogin(
            @RequestParam String username,
            @RequestParam String password,
            Model model) {

        // Real-time example (hardcoded for learning)
        if (username.equals("admin") && password.equals("admin")) {
            model.addAttribute("username", username);
            return "welcome1";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "login";
        }
    }
}
