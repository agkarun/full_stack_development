import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Person2 } from './person2';

describe('Person2', () => {
  let component: Person2;
  let fixture: ComponentFixture<Person2>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Person2]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Person2);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
