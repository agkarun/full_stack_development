import { Component } from '@angular/core';
import { ChatService } from '../chat-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-person2',
  imports: [FormsModule,CommonModule],
  templateUrl: './person2.html',
  styleUrl: './person2.css',
})
export class Person2 {
  public TypedMessage:string='';
  public AllMessages:string[]=[];
  constructor(private chatservice: ChatService){
    this.AllMessages=this.chatservice.messages;
  }
  sendMessage(name:string){
    this.chatservice.sendToAll(name+this.TypedMessage);
    this.AllMessages=this.chatservice.messages;
    this.TypedMessage="";
  }
}
