import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Person3 } from './person3';

describe('Person3', () => {
  let component: Person3;
  let fixture: ComponentFixture<Person3>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Person3]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Person3);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
