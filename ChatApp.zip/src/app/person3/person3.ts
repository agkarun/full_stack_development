import { Component } from '@angular/core';
import { ChatService } from '../chat-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-person3',
  imports: [FormsModule,CommonModule],
  templateUrl: './person3.html',
  styleUrl: './person3.css',
})
export class Person3 {
  TypedMessage:string="";
  public AllMessages:string[]=[];
  constructor(private chatservice: ChatService){
    this.AllMessages=chatservice.messages;
  }
  sendMessage(name:string){
    this.chatservice.sendToAll(name+this.TypedMessage);
    this.AllMessages=this.chatservice.messages;
    this.TypedMessage="";
  }
}
