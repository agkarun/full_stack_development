import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Person1 } from './person1/person1';
import { Person2 } from './person2/person2';
import { Person3 } from './person3/person3';
import { ChatService } from './chat-service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,Person1,Person2,Person3],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ChatApp');
}
