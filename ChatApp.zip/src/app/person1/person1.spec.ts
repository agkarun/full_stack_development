import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Person1 } from './person1';

describe('Person1', () => {
  let component: Person1;
  let fixture: ComponentFixture<Person1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Person1]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Person1);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
