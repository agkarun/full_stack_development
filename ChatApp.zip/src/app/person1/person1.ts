import { Component } from '@angular/core';
import { ChatService } from '../chat-service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-person1',
  imports: [CommonModule,FormsModule],
  templateUrl: './person1.html',
  styleUrl: './person1.css',
})
export class Person1 {
  public TypedMessage:string='';
  public AllMessages:string[]=[];
  constructor(private chatservice: ChatService){
    this.AllMessages=this.chatservice.messages;
  }
  sendMessage(name:string){
    this.chatservice.sendToAll(name+this.TypedMessage);
    this.AllMessages=this.chatservice.messages;
    this.TypedMessage="";
  }
  
}
